const menu=document.querySelector('.menu'),nav=document.querySelector('nav');menu.onclick=()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Close navigation':'Open navigation')};nav.querySelectorAll('a').forEach(a=>a.onclick=()=>{nav.classList.remove('open');menu.setAttribute('aria-expanded','false')});

if(document.getElementById("enquiry-form")){
const speciesSlugs=["african-parrots", "macaws", "cockatoos", "amazons", "conures", "caiques", "eclectus", "parakeets-small-psittacines"],speciesNames=["African Grey Parrots", "Macaw Parrots", "Cockatoo Parrots", "Amazon Parrots", "Conure Parrots", "Caique Parrots", "Eclectus Parrots", "Parakeets & Budgerigars"];const select=document.getElementById("species-select");speciesNames.forEach(n=>select.add(new Option(n,n)));const picked=speciesSlugs.indexOf(new URLSearchParams(location.search).get("species"));if(picked>=0)select.value=speciesNames[picked];

}
